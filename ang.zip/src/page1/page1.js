/* angular.module("myApp.page1",['ngRoute'])
.config(['$routeProvider','$locationProvider'],function($routeProvider,$locationProvider){
    $locationProvider.hashValue('!');
    $routeProvider.when('/page1',{
        templateUrl:'page1/page1.html',
        controller:'page1Ctrl'
    })
}).controller('page1Ctrl',function(){
    console.log('page1Ctrl');
});
  */

var app = angular.module("myApp.page1", ['ngRoute']);

app.config(function($routeProvider,$locationProvider) {
    console.log($locationProvider," lication ");
    //$locationProvider.html5Mode(true);   
    $routeProvider.when('/page1',{
        templateUrl:'page1/page1.html',
        controller:'page1Ctrl'
    })
}).controller('page1Ctrl',function(){
    console.log('page1Ctrl');
}); 