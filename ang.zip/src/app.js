var app = angular.module("myApp", ['ngRoute','myApp.page1','myApp.page2']);

app.config(function($routeProvider,$locationProvider) {
   $routeProvider.otherwise({
        redirectTo:'/page1'
    });
    //$locationProvider.html5Mode(true);  
});